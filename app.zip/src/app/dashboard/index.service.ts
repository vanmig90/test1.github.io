import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { DashboardData } from './mock-data/dashboard';

@Injectable({
  providedIn: 'root'
})
export class IndexService {

  constructor() { }

  GetDashboardData(): Observable<any> {
    return of(DashboardData);

  }
}
