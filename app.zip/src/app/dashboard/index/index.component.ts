import { Component, Inject, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/common';

import { IndexService } from '../index.service';
import { animate, state, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'icon-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss'],
  animations: [
    trigger('flipState', [
      state('active', style({
        transform: 'rotateY(179.9deg)'
      })),
      state('inactive', style({
        transform: 'rotateY(0)'
      })),
      transition('active => inactive', animate('500ms ease-out')),
      transition('inactive => active', animate('500ms ease-in'))
    ])
  ]
})

export class IndexComponent implements OnInit {
  flip: string = 'inactive';
  searchText = '';
  applications = [];
  isOpenNewWindow = false;
  loading = false;
  constructor(@Inject(DOCUMENT) private document: Document, private indexService: IndexService) { }

  ngOnInit(): void {
    this.getApplications();
  }

  applicationSearch() {
    if (this.searchText !== '') {
      return this.applications.filter(application => application.description.toLowerCase().indexOf(this.searchText.toLowerCase()) > -1 ||
        application.title.toLowerCase().indexOf(this.searchText.toLowerCase()) > -1);
    }
    return this.applications;
  }

  getApplications(): void {
    this.indexService.GetDashboardData().subscribe(response => {
      this.applications = response;
    }, error => {
    });
  }

  goToLink(url: string) {
    if (this.isOpenNewWindow) {
      window.open("//" + url, "_blank");
    }
    else {
      this.flip = (this.flip == 'inactive') ? 'active' : 'inactive';
      setTimeout(() => {
        this.flip = (this.flip == 'inactive') ? 'active' : 'inactive';
        setTimeout(() => {
          this.redirect(url);
        }, 800);
      }, 600);
    }
  }

  redirect(url: string): void {
    this.loading = true;
    setTimeout(() => {
      this.loading = false;
      window.open("//" + url, "_self");
    }, 800);
  }

}
