export const DashboardData =
    [
        {
            title: 'Open Account', url: 'www.google.com',
            statistics: [
                { transactionText: 'Open', transactionCount: 10, colorCode: '#D50000' },
                { transactionText: 'Inprogress', transactionCount: 5, colorCode: '#D81B60' },
                { transactionText: 'Completed', transactionCount: 7, colorCode: '#4A148C' }
            ],
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dapibus, leo id pulvinar vestibulum, ligula nisl tincidunt magna, eu volutpat leo neque quis justo.'
        },
        {
            title: 'Receivables and Payables', url: 'www.gmail.com',
            statistics: [
                { transactionText: 'Open', transactionCount: 10, colorCode: '#D50000' },
                { transactionText: 'Inprogress', transactionCount: 5, colorCode: '#D81B60' },
                { transactionText: 'Completed', transactionCount: 7, colorCode: '#4A148C' }
            ],
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dapibus, leo id pulvinar vestibulum, ligula nisl tincidunt magna, eu volutpat leo neque quis justo.'
        }
    ];