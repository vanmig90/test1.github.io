import { Component, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../../../service/common.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  @Output() clickHamburger: EventEmitter<boolean> = new EventEmitter();
  isCollapsed = false;
  styles = {
    'background-color': 'red'
  };
  isLoading = true;
  constructor(
    public router: Router,
    public commonService: CommonService) { }

  ngOnInit(): void {
  }

  toggle() {
    this.isCollapsed = !this.isCollapsed;
    this.clickHamburger.emit(this.isCollapsed);
    this.commonService.clickHamburger.next(this.isCollapsed);
  }

}


