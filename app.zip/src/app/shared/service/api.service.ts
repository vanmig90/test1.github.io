import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class ApiService {


    constructor(private http: HttpClient) { }

    get<T>(url: string, params: HttpParams | {
        [param: string]: string | string[];
    } = null) {
        const endPoint = `${url}`;
        return this.http.get<T>(endPoint, {
            params
        });
    }

    post<T>(url, data) {
        const endPoint = `${url}`;
        return this.http.post<T>(endPoint, data);
    }

    put<T>(url, data) {
        const endPoint = `${url}`;
        return this.http.put<T>(endPoint, data);
    }

    delete<T>(url) {
        const endPoint = `${url}`;
        return this.http.delete<T>(endPoint);
    }
}
